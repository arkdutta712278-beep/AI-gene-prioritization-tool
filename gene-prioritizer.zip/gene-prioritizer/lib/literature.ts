/**
 * Private literature RAG (Retrieval Augmented Generation)
 *
 * Stores and retrieves private research papers / clinical notes
 * using Pinecone vector database + Claude embeddings.
 *
 * Setup:
 *   1. Create a Pinecone account at pinecone.io (free tier available)
 *   2. Create an index named "gene-literature" with dimension 1536
 *   3. Set PINECONE_API_KEY and PINECONE_INDEX in Vercel env vars
 *   4. Use the /api/literature/upload endpoint to add PDFs
 *
 * If Pinecone is not configured, this module returns empty results
 * and the pipeline continues without private literature context.
 */

import type { LiteratureChunk } from "@/types";

const PINECONE_BASE = "https://api.pinecone.io";

// Simple cosine-similarity search via Pinecone REST API
export async function retrieveRelevantLiterature(
  queryText: string,
  topK = 3
): Promise<LiteratureChunk[]> {
  const apiKey = process.env.PINECONE_API_KEY;
  const indexName = process.env.PINECONE_INDEX;

  if (!apiKey || !indexName) {
    return [];
  }

  try {
    // Step 1: Embed the query using Claude's embedding approach
    // (We use a simple text representation since Anthropic doesn't yet
    //  expose a dedicated embeddings endpoint — use OpenAI ada-002 or
    //  a self-hosted model here in production)
    const queryEmbedding = await embedText(queryText);
    if (!queryEmbedding) return [];

    // Step 2: Query Pinecone
    const indexRes = await fetch(`${PINECONE_BASE}/indexes/${indexName}`, {
      headers: { "Api-Key": apiKey, Accept: "application/json" },
    });
    if (!indexRes.ok) return [];
    const indexData = await indexRes.json();
    const host = indexData.host;

    const queryRes = await fetch(`https://${host}/query`, {
      method: "POST",
      headers: {
        "Api-Key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        vector: queryEmbedding,
        topK,
        includeMetadata: true,
      }),
    });

    if (!queryRes.ok) return [];
    const queryData = await queryRes.json();

    return (queryData.matches || [])
      .filter((m: { score: number }) => m.score > 0.7)
      .map((m: { metadata: { text: string; source: string }; score: number }) => ({
        text: m.metadata?.text || "",
        source: m.metadata?.source || "Private literature",
        relevanceScore: m.score,
      }));
  } catch (err) {
    console.error("[Literature] RAG query failed:", err);
    return [];
  }
}

// Placeholder embedding function
// Replace with your embedding provider (OpenAI, Cohere, or self-hosted)
async function embedText(text: string): Promise<number[] | null> {
  // TODO: Replace with real embedding API call
  // Example using OpenAI:
  // const res = await fetch("https://api.openai.com/v1/embeddings", {
  //   method: "POST",
  //   headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
  //   body: JSON.stringify({ input: text, model: "text-embedding-ada-002" }),
  // });
  // const data = await res.json();
  // return data.data[0].embedding;
  console.info("[Literature] Embedding function not configured — returning null");
  void text;
  return null;
}

export function formatLiteratureContext(chunks: LiteratureChunk[]): string {
  if (!chunks.length) return "";
  return chunks
    .map((c, i) => `[${i + 1}] Source: ${c.source}\n${c.text}`)
    .join("\n\n");
}
