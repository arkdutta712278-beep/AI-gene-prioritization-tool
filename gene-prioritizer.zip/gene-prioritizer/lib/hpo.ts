/**
 * HPO JAX API client
 * Free public API — no auth required
 * https://hpo.jax.org/api/hpo
 */

import type { HPOTerm } from "@/types";

const HPO_BASE = "https://hpo.jax.org/api/hpo";

export interface HPOGene {
  geneSymbol: string;
  geneId: number;
  dbDiseases?: { diseaseId: string; diseaseName: string }[];
}

// Search HPO terms by keyword
export async function searchHPOTerms(query: string, max = 10): Promise<HPOTerm[]> {
  const res = await fetch(
    `${HPO_BASE}/search?q=${encodeURIComponent(query)}&max=${max}`,
    { next: { revalidate: 3600 } }
  );
  if (!res.ok) return [];
  const data = await res.json();
  return (data.terms || []).map((t: { id: string; name: string }) => ({
    id: t.id,
    name: t.name,
  }));
}

// Get genes associated with an HPO term
export async function getGenesForTerm(hpoId: string, limit = 100): Promise<HPOGene[]> {
  try {
    const res = await fetch(
      `${HPO_BASE}/term/${encodeURIComponent(hpoId)}/genes?limit=${limit}`,
      { next: { revalidate: 3600 } }
    );
    if (!res.ok) return [];
    const data = await res.json();
    return data.genes || [];
  } catch {
    return [];
  }
}

// Get full HPO term detail
export async function getTermDetail(hpoId: string): Promise<HPOTerm | null> {
  try {
    const res = await fetch(`${HPO_BASE}/term/${encodeURIComponent(hpoId)}`, {
      next: { revalidate: 86400 },
    });
    if (!res.ok) return null;
    const data = await res.json();
    const term = data.details;
    return { id: term.id, name: term.name, definition: term.definition };
  } catch {
    return null;
  }
}

// Build gene→HPO match map from a list of HPO terms
export async function buildGenePhenotypeMap(hpoTerms: HPOTerm[]): Promise<{
  geneCounts: Record<string, number>;
  geneHPOMatches: Record<string, string[]>;
  topGenes: string[];
}> {
  const geneCounts: Record<string, number> = {};
  const geneHPOMatches: Record<string, string[]> = {};

  const termGenes = await Promise.all(
    hpoTerms.slice(0, 10).map(async (term) => ({
      termName: term.name,
      genes: await getGenesForTerm(term.id),
    }))
  );

  for (const { termName, genes } of termGenes) {
    for (const g of genes) {
      geneCounts[g.geneSymbol] = (geneCounts[g.geneSymbol] || 0) + 1;
      if (!geneHPOMatches[g.geneSymbol]) geneHPOMatches[g.geneSymbol] = [];
      geneHPOMatches[g.geneSymbol].push(termName);
    }
  }

  const topGenes = Object.entries(geneCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 40)
    .map(([g]) => g);

  return { geneCounts, geneHPOMatches, topGenes };
}
