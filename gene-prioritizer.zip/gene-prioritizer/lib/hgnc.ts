/**
 * HGNC Hallucination Guard
 * Validates gene symbols against the HGNC REST API.
 * Free, no auth required: https://rest.genenames.org
 */

import type { ValidationResult } from "@/types";

const HGNC_BASE = "https://rest.genenames.org";

interface HGNCDoc {
  hgnc_id: string;
  symbol: string;
  name: string;
  prev_symbol?: string[];
  alias_symbol?: string[];
}

interface HGNCResponse {
  responseHeader: { status: number; QTime: number };
  response: { numFound: number; docs: HGNCDoc[] };
}

// Cache to avoid hammering the API on repeated lookups
const cache = new Map<string, ValidationResult>();

export async function validateGeneSymbol(symbol: string): Promise<ValidationResult> {
  const upper = symbol.toUpperCase().trim();

  if (cache.has(upper)) return cache.get(upper)!;

  try {
    // 1. Try exact symbol match
    const exactRes = await fetch(
      `${HGNC_BASE}/fetch/symbol/${encodeURIComponent(upper)}`,
      { headers: { Accept: "application/json" }, next: { revalidate: 86400 } }
    );
    const exactData: HGNCResponse = await exactRes.json();

    if (exactData.response.numFound > 0) {
      const doc = exactData.response.docs[0];
      const result: ValidationResult = {
        symbol: upper,
        valid: true,
        hgncId: doc.hgnc_id,
        approvedName: doc.name,
      };
      cache.set(upper, result);
      return result;
    }

    // 2. Try alias/previous symbol search
    const searchRes = await fetch(
      `${HGNC_BASE}/search/prev_symbol:${encodeURIComponent(upper)}+OR+alias_symbol:${encodeURIComponent(upper)}`,
      { headers: { Accept: "application/json" }, next: { revalidate: 86400 } }
    );
    const searchData: HGNCResponse = await searchRes.json();

    if (searchData.response.numFound > 0) {
      const doc = searchData.response.docs[0];
      const result: ValidationResult = {
        symbol: upper,
        valid: false,
        suggestedSymbol: doc.symbol,
        approvedName: doc.name,
        hgncId: doc.hgnc_id,
      };
      cache.set(upper, result);
      return result;
    }

    const invalid: ValidationResult = { symbol: upper, valid: false };
    cache.set(upper, invalid);
    return invalid;
  } catch {
    // Network failure — pass through, don't block prioritization
    return { symbol: upper, valid: true };
  }
}

export async function validateGeneSymbols(symbols: string[]): Promise<{
  validated: string[];
  hallucinations: string[];
  suggestions: Record<string, string>;
}> {
  const results = await Promise.all(symbols.map(validateGeneSymbol));

  const validated: string[] = [];
  const hallucinations: string[] = [];
  const suggestions: Record<string, string> = {};

  for (const r of results) {
    if (r.valid) {
      validated.push(r.symbol);
    } else {
      hallucinations.push(r.symbol);
      if (r.suggestedSymbol) suggestions[r.symbol] = r.suggestedSymbol;
    }
  }

  return { validated, hallucinations, suggestions };
}
