/**
 * Anthropic Claude API helpers
 * Uses the official @anthropic-ai/sdk
 */

import Anthropic from "@anthropic-ai/sdk";
import type { HPOTerm, CandidateGene } from "@/types";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ─── HPO Extraction from free text ───────────────────────────────────────────

export async function extractHPOFromText(
  freeText: string,
  existingTermIds: string[] = []
): Promise<HPOTerm[]> {
  const message = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1024,
    messages: [
      {
        role: "user",
        content: `You are a clinical genetics expert. Extract phenotypic terms from this clinical description and map each to its best HPO code.

Clinical text: "${freeText}"
Already selected HPO IDs (skip these): ${existingTermIds.join(", ") || "none"}

Rules:
- Only extract terms that clearly describe a clinical phenotype
- Use the most specific HPO term that fits
- Exclude vague terms like "developmental delay" if a more specific term fits
- Return 3–12 terms maximum

Return ONLY valid JSON, no markdown, no explanation:
{"hpo_terms":[{"id":"HP:XXXXXXX","name":"term name"}]}`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    return parsed.hpo_terms || [];
  } catch {
    return [];
  }
}

// ─── Gene Prioritization (hiPHIVE-style chain of thought) ────────────────────

export async function prioritizeGenesWithLLM(params: {
  hpoTerms: HPOTerm[];
  candidateGenes: string[];
  freeText?: string;
  inheritance: string[];
  literatureContext?: string;
  mode: "hybrid" | "llm" | "hpo";
}): Promise<Omit<CandidateGene, "validated">[]> {
  const { hpoTerms, candidateGenes, freeText, inheritance, literatureContext, mode } = params;

  const hpoList = hpoTerms.map((h) => `${h.id} (${h.name})`).join("\n  ");
  const geneList = candidateGenes.slice(0, 30).join(", ");
  const modeNote =
    mode === "llm"
      ? "You are the primary prioritizer — rely on your deep training knowledge of gene-disease associations."
      : "You are augmenting HPO database overlap scores. Focus your reasoning on phenotype specificity and inheritance fit.";

  const literatureSection = literatureContext
    ? `\nRelevant literature from private database:\n${literatureContext}\n`
    : "";

  const message = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 2048,
    messages: [
      {
        role: "user",
        content: `You are an expert clinical geneticist AI using a hiPHIVE-style chain-of-thought prioritization strategy. ${modeNote}

Patient HPO terms:
  ${hpoList}

Free text description: ${freeText || "(none)"}
Allowed inheritance modes: ${inheritance.join(", ")}
Candidate genes from HPO database: ${geneList}
${literatureSection}

For each top candidate gene, reason through ALL of the following:
1. Phenotype specificity — which HPO terms does this gene's known disease phenotype include?
2. Phenotype completeness — what fraction of the patient's terms does this gene explain?
3. Inheritance fit — does the gene's inheritance mode match the clinical context?
4. Cross-species evidence — is there mouse/zebrafish model support?
5. Literature support — any relevant evidence in the provided literature context?

Return ONLY valid JSON, no markdown, no preamble. Include exactly 6–8 top candidates:
{"genes":[{
  "gene":"SYMBOL",
  "rank":1,
  "combinedScore":0.92,
  "hpoPhenotypeScore":0.88,
  "llmConfidence":0.95,
  "exomiserScore":null,
  "inheritance":"Autosomal dominant",
  "omimId":"312750",
  "reasoning":"2–3 sentence clinical genetics rationale citing specific HPO terms and mechanism",
  "hpoMatches":["Seizure","Hypotonia"],
  "literatureSnippets":[]
}]}`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    return (parsed.genes || []).map((g: Omit<CandidateGene, "validated">) => ({
      ...g,
      validated: false,
    }));
  } catch {
    return [];
  }
}
