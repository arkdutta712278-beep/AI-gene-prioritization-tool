/**
 * Exomiser service client
 *
 * This module calls the Exomiser REST prioritiser running on a separate server
 * (Railway / Fly.io / EC2). If EXOMISER_API_URL is not set, it gracefully
 * returns null so the rest of the pipeline continues without it.
 *
 * To deploy Exomiser:
 *   1. Download exomiser-cli-15.x.jar from github.com/exomiser/Exomiser/releases
 *   2. Download phenotype data (~5 GB) from data.monarchinitiative.org/exomiser/latest
 *   3. Optionally download hg38 variant data (~80 GB)
 *   4. Wrap it in the FastAPI server in /exomiser-service/ (included in this repo)
 *   5. Set EXOMISER_API_URL=https://your-exomiser-service.railway.app
 */

import type { ExomiserResult } from "@/types";
import type { HPOTerm } from "@/types";

interface ExomiserPrioritiserRequest {
  hpoIds: string[];
  genes: string[];
}

interface ExomiserServiceResponse {
  results: ExomiserResult[];
  processingMs: number;
}

export async function callExomiserPrioritiser(
  hpoTerms: HPOTerm[],
  candidateGenes: string[]
): Promise<ExomiserResult[] | null> {
  const baseUrl = process.env.EXOMISER_API_URL;

  if (!baseUrl) {
    console.info("[Exomiser] EXOMISER_API_URL not set — skipping");
    return null;
  }

  try {
    const body: ExomiserPrioritiserRequest = {
      hpoIds: hpoTerms.map((t) => t.id),
      genes: candidateGenes,
    };

    const res = await fetch(`${baseUrl}/api/prioritise`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30_000),
    });

    if (!res.ok) {
      console.error(`[Exomiser] Service returned ${res.status}`);
      return null;
    }

    const data: ExomiserServiceResponse = await res.json();
    return data.results;
  } catch (err) {
    console.error("[Exomiser] Failed to reach service:", err);
    return null;
  }
}

// Merge Exomiser phenotype scores into gene list
export function mergeExomiserScores(
  genes: Array<{ gene: string; combinedScore: number; hpoPhenotypeScore: number }>,
  exomiserResults: ExomiserResult[]
): typeof genes {
  const exMap = new Map(exomiserResults.map((r) => [r.geneSymbol, r]));

  return genes.map((g) => {
    const ex = exMap.get(g.gene);
    if (!ex) return g;

    // Weighted merge: 40% LLM/HPO database, 60% Exomiser (when available)
    const merged = ex.combinedScore * 0.6 + g.combinedScore * 0.4;

    return {
      ...g,
      exomiserScore: ex.combinedScore,
      hpoPhenotypeScore: Math.max(g.hpoPhenotypeScore, ex.phenotypeScore),
      combinedScore: parseFloat(merged.toFixed(3)),
    };
  });
}
