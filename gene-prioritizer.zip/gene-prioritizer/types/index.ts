export interface HPOTerm {
  id: string;
  name: string;
  definition?: string;
}

export interface CandidateGene {
  gene: string;
  rank: number;
  combinedScore: number;
  hpoPhenotypeScore: number;
  llmConfidence: number | null;
  exomiserScore: number | null;
  inheritance: string;
  omimId: string | null;
  hpoMatches: string[];
  reasoning: string;
  literatureSnippets?: string[];
  validated: boolean;
}

export interface PrioritizationRequest {
  freeText?: string;
  hpoTerms: HPOTerm[];
  inheritance: string[];
  mode: "hybrid" | "llm" | "hpo";
  maxGenes?: number;
}

export interface PrioritizationResponse {
  genes: CandidateGene[];
  resolvedHPOTerms: HPOTerm[];
  hallucinations: string[];
  exomiserUsed: boolean;
  literatureUsed: boolean;
  processingMs: number;
}

export interface ValidationResult {
  symbol: string;
  valid: boolean;
  hgncId?: string;
  approvedName?: string;
  suggestedSymbol?: string;
}

export interface ExomiserResult {
  geneSymbol: string;
  combinedScore: number;
  phenotypeScore: number;
  variantScore: number;
  modeOfInheritance: string;
}

export interface LiteratureChunk {
  text: string;
  source: string;
  relevanceScore: number;
}
