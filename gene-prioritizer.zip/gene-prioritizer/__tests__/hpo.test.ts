import { buildGenePhenotypeMap } from "@/lib/hpo";
import type { HPOTerm } from "@/types";

global.fetch = jest.fn();
const mockFetch = fetch as jest.MockedFunction<typeof fetch>;

function mockGeneResponse(genes: { geneSymbol: string }[]) {
  return {
    ok: true,
    json: async () => ({ genes }),
  } as Response;
}

describe("buildGenePhenotypeMap", () => {
  beforeEach(() => mockFetch.mockClear());

  it("counts gene overlap correctly", async () => {
    const terms: HPOTerm[] = [
      { id: "HP:0001250", name: "Seizure" },
      { id: "HP:0001290", name: "Hypotonia" },
    ];

    // MECP2 appears in both terms, SCN1A in only one
    mockFetch
      .mockResolvedValueOnce(mockGeneResponse([{ geneSymbol: "MECP2" }, { geneSymbol: "SCN1A" }]))
      .mockResolvedValueOnce(mockGeneResponse([{ geneSymbol: "MECP2" }]));

    const { geneCounts, topGenes } = await buildGenePhenotypeMap(terms);

    expect(geneCounts["MECP2"]).toBe(2);
    expect(geneCounts["SCN1A"]).toBe(1);
    expect(topGenes[0]).toBe("MECP2");
  });
});
