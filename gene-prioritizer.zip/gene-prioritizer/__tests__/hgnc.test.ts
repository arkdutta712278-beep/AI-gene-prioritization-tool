/**
 * Unit tests for the HGNC hallucination guard
 * Run: npm test
 */

import { validateGeneSymbol, validateGeneSymbols } from "@/lib/hgnc";

// Mock fetch so tests don't hit the real HGNC API
global.fetch = jest.fn();

const mockFetch = fetch as jest.MockedFunction<typeof fetch>;

function mockHGNCResponse(numFound: number, symbol = "MECP2", name = "methyl CpG binding protein 2") {
  return {
    ok: true,
    json: async () => ({
      responseHeader: { status: 0, QTime: 1 },
      response: {
        numFound,
        docs: numFound > 0 ? [{ hgnc_id: "HGNC:6990", symbol, name }] : [],
      },
    }),
  } as Response;
}

describe("validateGeneSymbol", () => {
  beforeEach(() => mockFetch.mockClear());

  it("returns valid=true for a real gene symbol", async () => {
    mockFetch.mockResolvedValueOnce(mockHGNCResponse(1));
    const result = await validateGeneSymbol("MECP2");
    expect(result.valid).toBe(true);
    expect(result.hgncId).toBe("HGNC:6990");
  });

  it("returns valid=false for a hallucinated symbol", async () => {
    mockFetch
      .mockResolvedValueOnce(mockHGNCResponse(0))   // exact search miss
      .mockResolvedValueOnce(mockHGNCResponse(0));   // alias search miss
    const result = await validateGeneSymbol("FAKEGENE123");
    expect(result.valid).toBe(false);
  });

  it("suggests correct symbol for an outdated name", async () => {
    mockFetch
      .mockResolvedValueOnce(mockHGNCResponse(0))
      .mockResolvedValueOnce(mockHGNCResponse(1, "MECP2", "methyl CpG binding protein 2"));
    const result = await validateGeneSymbol("MeCP2");
    expect(result.valid).toBe(false);
    expect(result.suggestedSymbol).toBe("MECP2");
  });
});

describe("validateGeneSymbols", () => {
  beforeEach(() => mockFetch.mockClear());

  it("separates valid from hallucinated symbols", async () => {
    mockFetch
      .mockResolvedValueOnce(mockHGNCResponse(1, "MECP2"))
      .mockResolvedValueOnce(mockHGNCResponse(0))
      .mockResolvedValueOnce(mockHGNCResponse(0));
    const { validated, hallucinations } = await validateGeneSymbols(["MECP2", "FAKEGENE"]);
    expect(validated).toContain("MECP2");
    expect(hallucinations).toContain("FAKEGENE");
  });
});
