/**
 * GET /api/exomiser/health
 * Check whether the Exomiser backend is reachable
 */

import { NextResponse } from "next/server";

export async function GET() {
  const url = process.env.EXOMISER_API_URL;

  if (!url) {
    return NextResponse.json({ configured: false, healthy: false });
  }

  try {
    const res = await fetch(`${url}/health`, { signal: AbortSignal.timeout(5000) });
    return NextResponse.json({ configured: true, healthy: res.ok });
  } catch {
    return NextResponse.json({ configured: true, healthy: false });
  }
}
