/**
 * GET /api/hpo?q=seizure&max=10
 * Proxy for HPO JAX search API — avoids CORS issues from the browser
 */

import { NextRequest, NextResponse } from "next/server";
import { searchHPOTerms } from "@/lib/hpo";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") || "";
  const max = parseInt(req.nextUrl.searchParams.get("max") || "10");

  if (!q || q.length < 2) {
    return NextResponse.json({ terms: [] });
  }

  const terms = await searchHPOTerms(q, Math.min(max, 20));
  return NextResponse.json({ terms });
}
